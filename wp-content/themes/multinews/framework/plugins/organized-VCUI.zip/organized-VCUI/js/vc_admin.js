jQuery(document).ready(function($) {
   $('.vc_navbar li .wpb_edit_inline').parent().parent().addClass('pull-right');
});